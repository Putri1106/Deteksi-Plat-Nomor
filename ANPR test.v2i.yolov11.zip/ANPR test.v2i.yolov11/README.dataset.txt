# ANPR test > 2023-11-30 6:48pm
https://universe.roboflow.com/parkets/anpr-test-py7gr

Provided by a Roboflow user
License: CC BY 4.0

